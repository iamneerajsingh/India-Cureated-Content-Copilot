# Section 10 – Scheduled prompt pack
> Copy-paste versions: `03_Prompt-Packs/Learner-Copy-Paste-Prompts.txt` (for the class Teams chat) and `03_Prompt-Packs/Scheduled-Prompts.csv`.
> Replace anything in **[brackets]** with your own role, project or priorities.

### Daily (these drive DAU)
| # | Agent | Name | Time | Prompt |
|---|---|---|---|---|
| D1 | Personal News Digest | Morning briefing | 8:30 AM | `I am a [role] working on [project/area]. Give me the 5 most important company-wide updates from the last 24 hours that matter to my role, as a table: Priority (Critical/Important/FYI) – Headline – Why it matters to me – Action and deadline.` |
| D2 | Plan My Day | Start my day | 9:00 AM | `Create a time-blocked plan for today from my calendar, email, Teams, and tasks: Time – Activity – Priority – Why now. List my top 3 outcomes and what I can postpone or delegate.` |
| D3 | Project Delta Digest | Daily project delta | 10:00 AM | `Give me today's digest for [project] — TL;DR, completed, in progress, blockers (owner, days stuck), and risks from the last 24 hours, with sources. Flag anything idle more than 5 days.` |
| D4 | Plan My Day | Wrap my day | 6:00 PM | `Wrap my day: what I completed, what slipped, decisions I owe, and tomorrow's top 3 priorities.` |
| D5 | Plan My Day | Meeting-heavy day check | 8:45 AM | `How heavy is my meeting load today? Which meetings can I skip, shorten, or delegate, and where is my best focus block?` |

### Weekly (these drive PRU and depth)
| # | Agent | Name | When | Prompt |
|---|---|---|---|---|
| W1 | Project Delta Digest | Leadership recap | Fri 4:00 PM | `Give me a leadership-ready weekly digest for [project] — TL;DR, milestones, top 3 risks, momentum signals, and the one decision I need from leadership. One page.` |
| W2 | Project Delta Digest | Escalate vs watch | Thu 3:00 PM | `What should I escalate now vs watch for another week on [project]? Two lists with risk score (1–5), owner, rationale, and source.` |
| W3 | Plan My Day | Weekly look-ahead | Mon 8:45 AM | `Give me a weekly look-ahead: key meetings, deadlines, milestones, meeting load, and my top 3 priorities for the week.` |
| W4 | Personal News Digest | Leadership voice | Mon 8:30 AM | `Summarise messages from my leadership chain and company executives in the last 7 days. Key quotes (under 20 words) and actions for my team.` |
| W5 | AI Learning Advisor | Learning check-in | Mon 4:00 PM | `I am a [role] building skills in [topic]. Give me this week's single most valuable skill, one 20-minute Microsoft Learn activity with a link, and one question to test what I learned last week.` |
| W6 | AI Learning Advisor | What's new | Fri 12:00 PM | `What's new this week in Microsoft 365 Copilot and agents that a [role] should try? Top 3, each with a Microsoft Learn link and a 5-minute try-it step.` |

### Trainer recommendation by audience
| Audience | Suggested "Schedule 3" |
|---|---|
| Any employee | D1 + D2 + D4 |
| Project / delivery managers | D2 + D3 + W1 |
| Managers / leaders | D1 + D2 + W4 |
| People building skills / champions | D2 + W5 + W6 |


---
*Part of the MS-4019 CUR_IND2 "A Day with Project Nexus" demo pack. See README.md for the full flow, environment setup and how to schedule prompts.*
