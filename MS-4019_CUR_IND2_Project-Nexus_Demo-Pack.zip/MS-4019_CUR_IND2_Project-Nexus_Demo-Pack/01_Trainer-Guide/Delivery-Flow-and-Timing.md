# Delivery flow and timing

### The day at a glance
| Time | Arjun's question | Agent | Outcome | MS-4019 module | Scheduled? |
|---|---|---|---|---|---|
| 8:30 AM | *What changed that matters to me?* | **Personal News Digest** | Understand | M1 | ✅ Daily |
| 9:00 AM | *What matters today?* | **Plan My Day** (+ Prompt Coach) | Prioritize | M1, M2 | ✅ Daily ×2 |
| 10:00 AM | *Where does my project really stand?* | **Project Delta Digest** (built in Agent Builder) | Execute | M3 | ✅ Daily + Weekly |
| 11:30 AM | *Why is adoption dropping?* | Analyst | Investigate | M2 (lab) | Optional |
| 1:30 PM | *What should we do next?* | Researcher + Idea Coach + Writing Coach | Recommend | M2 (labs) | Optional |
| 3:00 PM | *Can the team serve themselves?* | SharePoint agent + share in Teams | Scale | M3, M4 (lab) | n/a |
| 4:00 PM | *What do I need to learn next?* | **AI Learning Advisor** | Grow | M6 | ✅ Weekly |
| 5:30 PM | *What's set up for tomorrow?* | Wrap my day + "Schedule 3" | Sustain | M1, M4, M5 | ✅ Learners schedule 3 |
| Next day | *(nothing to ask: digests arrive on their own)* | Scheduled prompts | **Adoption** | n/a | n/a |

#### Suggested timing (1-day ILT)
| Block | Content | Time |
|---|---|---|
| Morning | Module 1 (official) + Section 0 + Section 1 + Section 2 | ~2 h |
| Late morning | Module 2 (official) + Section 4 (Analyst lab) + Section 5 (Researcher and choice labs) | ~2 h |
| Afternoon | Module 3 (official) + Section 3 (Delta Digest = Copilot Chat agent lab) + Section 6 (SharePoint lab) | ~2 h |
| Late afternoon | Module 4 (official) + Section 7 + Section 8 + Section 9 | ~1.5 h |

> The table above shows the **story** order. In delivery, follow the **official module order**: each section sits inside its module, and Arjun's clock time is the narrative device.

---

### MS-4019 topic coverage map
| MS-4019 module / topic | Covered in |
|---|---|
| **M1** What are agents? (prebuilt / template / custom) | S1 |
| **M1** Who can create and use agents? | S1, S7 |
| **M1** Benefits of using agents | S2 |
| **M1** Enhance collaboration using agents | S6 |
| **M1** IT governance controls | S8 |
| **M2** Analyst agent + Exercise 1 | S4 |
| **M2** Researcher agent + Exercise 2 | S5 |
| **M2** Prompt Coach | S2 |
| **M2** Idea Coach / Writing Coach | S5 |
| **M2** Exercise 3: agent of your choice | S5 (pick a coach or curated agent) |
| **M3** Tools used to create agents | S3 |
| **M3** Components of an agent | S3 |
| **M3** Create an agent in Copilot Chat (Describe / Configure) + Exercise 1 | S3 |
| **M3** Create an agent in SharePoint + Exercise 2 | S6 |
| **M3** Test and edit your agents | S3 |
| **M3** Manage your agents | S6, S8 |
| **M4** Share an agent with other users / in Teams | S6 |
| **M4** Interact with agents (permissions, chat history) | S6, S8 |
| **M5** Learning path review | S8 |
| **M6** India preset: templates + scheduled prompts | S1, S2, S3, S7, S8, S10 |

---

### Modular delivery: drop any section
Every section is self-contained and has an **"If you drop this section"** note telling you how to keep the story going.

| Section | Can drop? | Minimum to keep if dropped |
|---|---|---|
| S0 Story setup | ⚠️ Not recommended | One-line persona intro |
| S1 Personal News Digest | ✅ | Explain agent types using Plan My Day |
| S2 Plan My Day | ✅ | Show Prompt Coach in S3; move "Wrap my day" to S8 |
| S3 Project Delta Digest | ✅ | Use the official lab's own agent for the Module 3 build |
| S4 Analyst | ✅ | Run the official lab as self-paced |
| S5 Researcher + coaches | ✅ | Run the official labs as self-paced |
| S6 SharePoint agent | ✅ | Keep one slide on sharing and permissions |
| S7 AI Learning Advisor | ✅ | Mention it as an optional schedule in S8 |
| S8 Wrap + Schedule 3 | ❌ **Never drop** | This is where adoption happens |
| S9 Close + follow-up | ⚠️ Keep the follow-up | Day 2 / Day 7 nudges |

**Common short versions:**
- **Core 4 only** (customer has the curated templates): S0 → S1 → S2 → S3 → S7 → S8
- **No templates available**: S0 → S2 (in Copilot Chat) → S4 → S5 → S6 → S8 (schedule Copilot Chat prompts)
- **Build-focused audience**: S0 → S3 → S6 → S7 → S8

---
*Part of the MS-4019 CUR_IND2 "A Day with Project Nexus" demo pack. See README.md for the full flow, environment setup and how to schedule prompts.*
