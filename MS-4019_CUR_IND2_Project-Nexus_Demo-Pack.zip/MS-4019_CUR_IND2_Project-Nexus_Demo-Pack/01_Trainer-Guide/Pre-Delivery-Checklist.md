# Pre-delivery checklist – MS-4019 CUR_IND2 · A Day with Project Nexus

## A. CSM → customer (2+ weeks before)
- [ ] Number of learners with a **Microsoft 365 Copilot** licence (not only Copilot Chat)
- [ ] **Agents** tab enabled for the learners
- [ ] Which of these are enabled: Personal News Digest · Plan My Day · Project Delta Digest · AI Learning Advisor · Researcher · Analyst · Prompt/Idea/Writing Coach
- [ ] Agent Builder (create agent) allowed for business users
- [ ] SharePoint agents allowed; learners have a site with Edit permission
- [ ] Web / public-website grounding allowed
- [ ] Scheduled prompts available to users
- [ ] Target audience and persona (e.g. project managers, operations, finance, executives)
- [ ] Customer's goals for the session (adoption, specific use cases)

## B. CSC → AER / pre-delivery instructions
- [ ] Preset: **CUR_IND2 – Elevate**
- [ ] Persona / role focus
- [ ] Agents to include and **sections to drop** (see the drop matrix in the README)
- [ ] Known environment limits (e.g. "no web grounding", "templates not enabled")
- [ ] Baseline Agent MAU / PRU recorded for day-30 comparison

## C. MTT (1–2 days before)
- [ ] Dry run of every included section in the delivery tenant
- [ ] Confirm the **Schedule this prompt** flow works, both inside agents and in Copilot Chat
- [ ] Upload `04_Sample-Data/Project-Nexus` to a demo SharePoint folder
- [ ] Pre-build **Nexus Delta Digest** and **Nexus Help Desk** as backups
- [ ] Personalise prompts if the persona isn't a Program Manager
- [ ] Prepare the class Teams chat; paste `Learner-Copy-Paste-Prompts.txt`
- [ ] Update any UI labels in the pack that differ from the tenant

## D. In class: availability check (before each section)
| Learners who can see the agent | Action |
|---|---|
| Most | Hands-on |
| Some | Pair up; others observe and use the fallback prompt in Copilot Chat |
| None | Demo only, or skip the section (see "If you drop this section") |

## E. After class
- [ ] % of learners with at least 3 scheduled prompts recorded
- [ ] Day 2 and Day 7 nudges posted
- [ ] Day 30 MAU / PRU comparison shared with the CSM
