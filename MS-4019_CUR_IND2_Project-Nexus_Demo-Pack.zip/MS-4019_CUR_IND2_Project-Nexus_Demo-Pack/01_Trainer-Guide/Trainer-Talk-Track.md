# Trainer talk track: story lines, teaching moments and bridges

> Read these aloud to keep the story flowing. If you drop a section, use the next section's opening line.


## Section 0 – Story setup: meet Arjun (5 min)

**Trainer talk track**
> "Meet Arjun. He's not short of tools, he's short of attention. Today we'll watch him hand one problem at a time to an agent. Then he does the thing that matters most: he **schedules** the agent, so tomorrow it's waiting for him. By the end of today you'll do the same for your own work."


## Section 1 – 8:30 AM · Personal News Digest · UNDERSTAND (15 min)

**Business scenario**
It's 8:30 and Arjun opens his laptop. Overnight there's a CEO note on AI, a policy change on data handling, an HR deadline, an IT outage notice and 40 newsletters. Somewhere in there are the two things that will change his steering committee message.

**Teaching moment**
> *Search asks: "What happened?" Personal News Digest asks: "What happened **that matters to me**?"*

**Bridge to the next section**
> "Arjun now knows what's changing **outside** his project. But his calendar, inbox and to-do list are still fighting for his attention. Next problem: **what actually matters today?**"


## Section 2 – 9:00 AM · Plan My Day (+ Prompt Coach) · PRIORITIZE (15 min)

**Business scenario**
Arjun has 9 meetings, a steering committee deck to draft, a stuck workstream and 30 minutes set aside to learn. He doesn't need another to-do list. He needs **prioritisation**. At 9:40 Priya asks for a 90-minute deep-dive on the Finance BU adoption drop, and the plan has to change.

**Teaching moment**
> *The first prompt shows **planning**. The plot twist shows something more valuable: **agentic experiences earn their place when circumstances change.***

**Bridge to the next section**
> "Arjun's top outcome today is a clear Nexus status for the steering committee. But status lives in six people's heads, three trackers and a hundred messages. Instead of chasing people, he'll **build an agent** that does the chasing."


## Section 3 – 10:00 AM · Project Delta Digest (built in Agent Builder) · EXECUTE (25 min)

**Business scenario**
Every Friday Arjun spends about 2 hours collecting updates from six workstream leads for a status report that's out of date by Monday. Risks show up late. Leadership hears about blockers after they've already slipped a milestone.

**Teaching moment**
> *"You didn't write an agent from a blank page. You **started from a template, tailored it, tested it and scheduled it**. That's the everyday business-user way to build agents."*

**Bridge to the next section**
> "The first digest shows why Priya is worried: **Finance weekly active users are down three weeks running**, and two Finance items (workshops and template enablement) are **blocked**. Arjun has the usage and survey data, but no time to dig through a spreadsheet before his 90-minute deep-dive. Time for the **Analyst**."


## Section 4 – 11:30 AM · Analyst · INVESTIGATE (20 min + official lab)

**Business scenario**
The Delta Digest flagged a drop in Finance adoption. Arjun has the Nexus adoption data (weekly active users by business unit, licences, survey sentiment). Priya wants to know **why** by this afternoon.

**Bridge to the next section**
> "Arjun now knows **what** is happening: Finance users weren't trained on agents and don't see their use cases. Priya wants a **recommendation**, backed by evidence, for what to do next."


## Section 5 – 1:30 PM · Researcher + Idea Coach + Writing Coach · RECOMMEND (20 min + official lab)

**Business scenario**
Arjun has to recommend the **next phase** of Nexus: how to bring agent adoption back up in Finance. He needs internal context (what's been tried and what the team said) **and** external evidence (what's worked elsewhere). He then needs to pressure-test the idea and write a crisp note to Priya.

**Teaching moment**
> *Copilot Chat is for a quick answer. **Researcher** is for depth and citations. **Coaches** are for improving your thinking and writing. Pick the agent that matches the depth you need.*

**Bridge to the next section**
> "Priya approves the plan. Now Arjun's team is about to be flooded with questions: *How do I get a licence? Where's the training? Who's my champion?* He can't answer them all, so he gives the team an agent that can."


## Section 6 – 3:00 PM · SharePoint agent + sharing in Teams · SCALE (10 min, brief)


## Section 7 – 4:00 PM · AI Learning Advisor · GROW (15 min)

**Business scenario**
Priya approved the plan, and added one more thing: *"You'll run the Finance agent workshops yourself."* Arjun is comfortable with Copilot, but he isn't confident explaining **agent grounding, knowledge, Agent Builder vs. Copilot Studio, or governance** to a room of finance professionals. The project has exposed a skill gap.

**Teaching moment**
> *That's the difference between **content discovery** and **personalised learning**.*

**Bridge to the next section**
> "It's 5:30. Arjun's day started with 200 unread items and no plan. Let's see what he's set up for tomorrow."


## Section 8 – 5:30 PM · Wrap my day: schedule, govern, commit (15 min)


## Section 9 – Next morning · The adoption moment (trainer close + follow-up)

**Close the session**
> "Tomorrow at 8:30, your first digest will be waiting for you. You didn't just *try* an agent today. You made it part of your workday."

Shift the mindset from **"I tried an agent"** to **"I use this agent as part of my workflow."**


---
*Part of the MS-4019 CUR_IND2 "A Day with Project Nexus" demo pack. See README.md for the full flow, environment setup and how to schedule prompts.*
