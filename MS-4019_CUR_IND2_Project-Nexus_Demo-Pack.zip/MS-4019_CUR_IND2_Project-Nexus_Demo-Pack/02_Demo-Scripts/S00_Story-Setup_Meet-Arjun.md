# Section 0 – Story setup: meet Arjun (5 min)

> **Where it runs:** Opening of the curated day, right after the Module 1 introduction slide. Keep it to one slide and a short story; Arjun comes back in every module.

### Overview
The story ties all of MS-4019 together. Arjun's day goes from **Understand → Prioritize → Execute → Grow**. Each agent fixes one real problem in his day. Each one ends with a **scheduled prompt**, so that tomorrow the agent comes to Arjun before he has to ask.

### Persona
| | |
|---|---|
| **Name** | Arjun Mehta |
| **Role** | Program Manager, Contoso India (IT services, Bengaluru) |
| **Project** | **Project Nexus**: Contoso's internal rollout of Microsoft 365 Copilot and agents to 2,000 employees across four business units (Delivery, Sales, Finance, HR) |
| **Reports to** | Priya Nair, VP Transformation |
| **Team** | 6 workstream leads, 2 change champions, 1 analyst |
| **A typical day** | 9 meetings, about 200 emails and Teams messages, 3 status reports, 1 steering committee each week |

> Project Nexus is the same internal initiative used in the official MS-4019 Analyst lab. That lets the story lead straight into the official lab exercises.

### The business scenario
On Monday Arjun has a steering committee with Priya. She wants three things:
1. A clear view of where Nexus stands.
2. An explanation of why adoption in one business unit is falling.
3. A recommendation for the next phase, which will use **agents**.

Arjun has one day, too much information and no time to chase people.

### Pain points (the opening hook)
| # | Pain point | Arjun's question | Agent that answers it |
|---|---|---|---|
| 1 | Information overload | *"What changed that matters to me?"* | Personal News Digest |
| 2 | Too many priorities competing | *"What actually matters today?"* | Plan My Day |
| 3 | Chasing status across teams | *"Where does my project really stand?"* | Project Delta Digest |
| 4 | Data he can't interpret quickly | *"Why is adoption dropping?"* | Analyst |
| 5 | Needing a researched recommendation | *"What should we do next?"* | Researcher + Idea Coach + Writing Coach |
| 6 | The same team questions every day | *"Can the team serve themselves?"* | SharePoint agent |
| 7 | A skill gap the project exposed | *"What do I need to learn next?"* | AI Learning Advisor |

### Trainer talk track
> "Meet Arjun. He's not short of tools, he's short of attention. Today we'll watch him hand one problem at a time to an agent. Then he does the thing that matters most: he **schedules** the agent, so tomorrow it's waiting for him. By the end of today you'll do the same for your own work."

### Learner action
Ask each learner to write down **one recurring moment in their own week**, like Arjun's 8:30 news check. Say they'll schedule an agent for it before they leave.


---
*Part of the MS-4019 CUR_IND2 "A Day with Project Nexus" demo pack. See README.md for the full flow, environment setup and how to schedule prompts.*
