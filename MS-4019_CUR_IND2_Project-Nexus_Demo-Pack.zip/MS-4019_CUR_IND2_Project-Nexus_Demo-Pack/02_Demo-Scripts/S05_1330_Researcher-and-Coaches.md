# Section 5 – 1:30 PM · Researcher + Idea Coach + Writing Coach · RECOMMEND (20 min + official lab)

> **MS-4019 topics covered:** Module 2, *Examine the Researcher agent*, *Examine the Idea Coach agent*, *Examine the Writing Coach agent*; **Labs:** *Exercise 2 – Use the Researcher agent* and *Exercise 3 – Use a prebuilt agent of your choice*.

### Overview
- **Researcher** carries out deep, multi-step research across work data (emails, meetings, files) and the web (where enabled), and produces a well-structured report with citations.
- **Idea Coach** stress-tests a plan from several angles.
- **Writing Coach** turns a rough draft into a polished message.

### Business scenario
Arjun has to recommend the **next phase** of Nexus: how to bring agent adoption back up in Finance. He needs internal context (what's been tried and what the team said) **and** external evidence (what's worked elsewhere). He then needs to pressure-test the idea and write a crisp note to Priya.

### Pain points
- Research spread across mail, meetings, files and the web.
- Recommendations that aren't challenged before they reach leadership.
- Long, unclear status emails.

### Business benefits
- A recommendation with sources in under 15 minutes.
- Better decisions through structured challenge.
- Clear, professional leadership communication.

### Learning objectives
1. Use Researcher to combine internal and external sources into a cited report.
2. Use Idea Coach to challenge a recommendation.
3. Use Writing Coach to tailor a message for an executive.
4. Choose the right prebuilt agent for the job (Copilot Chat vs. Researcher vs. the coaches).

### Environment setup
| Item | Requirement |
|---|---|
| Licence | Microsoft 365 Copilot (Researcher may have usage limits; check them in your tenant) |
| Agents | **Researcher**, **Idea Coach**, **Writing Coach** (prebuilt) |
| Data | Learner's own mail and meetings; Nexus sample files; web grounding if the tenant allows it |
| Timing note | Researcher can take a few minutes. **Start it, then teach Idea Coach while it runs.** |

### Demo walkthrough
1. Open **Researcher** → run **Prompt 5A**. Point out the clarifying questions and the research plan.
2. While it runs, open **Idea Coach** → run **Prompt 5B**.
3. Return to Researcher's report and point out the **citations**.
4. Open **Writing Coach** → run **Prompt 5C**.

**Prompt 5A – Researcher**
```
Goal: Recommend how to recover Microsoft 365 Copilot agent adoption in our Finance business unit within 60 days.
Context: I lead Project Nexus. Finance weekly active users fell about 30% over three weeks. Analysis suggests Finance users were not trained on agents and don't see role-relevant use cases.
Source: Use my emails, meeting notes, and the Project Nexus files for internal context, and credible external sources (Microsoft adoption guidance, industry case studies) for proven practices.
Expectations: A 1-page report with: situation, 3 options (effort, impact, risk), a recommended option, a 30-60 day plan, and success metrics. Cite every source.
```
**Prompt 5B – Idea Coach**
```
Here is my plan: run role-based agent workshops for Finance, appoint 5 Finance champions, and give every attendee three scheduled prompts on day one. Challenge this plan from the perspective of a CFO, a busy finance analyst, and IT governance. What would make it stronger?
```
**Prompt 5C – Writing Coach**
```
Rewrite this as a crisp note to my VP. Professional, confident, under 120 words, with one clear ask: [paste Researcher's recommendation summary]
```

### Learner hands-on
- **Official lab: Exercise 2 – Use the Researcher agent** (own data).
- **Official lab: Exercise 3 – Use a prebuilt agent of your choice.** Encourage learners to pick a **coach** agent or one of the **curated agents** from this day.

### Schedule it 🔁 *(optional)*
`Weekly, Monday 8:00 AM (Researcher or Copilot Chat) – What changed in Microsoft 365 Copilot and agent adoption best practice in the last 7 days that is relevant to an internal rollout? 5 bullets with sources.`

### Teaching moment
> *Copilot Chat is for a quick answer. **Researcher** is for depth and citations. **Coaches** are for improving your thinking and writing. Pick the agent that matches the depth you need.*

### Bridge to the next section
> "Priya approves the plan. Now Arjun's team is about to be flooded with questions: *How do I get a licence? Where's the training? Who's my champion?* He can't answer them all, so he gives the team an agent that can."

### If you drop this section
Keep Researcher for the official lab only. Coaches can be self-explored in Exercise 3.


---
*Part of the MS-4019 CUR_IND2 "A Day with Project Nexus" demo pack. See README.md for the full flow, environment setup and how to schedule prompts.*
