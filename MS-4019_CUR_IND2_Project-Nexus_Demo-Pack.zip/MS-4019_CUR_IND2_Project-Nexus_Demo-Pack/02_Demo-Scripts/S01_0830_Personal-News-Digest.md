# Section 1 – 8:30 AM · Personal News Digest · UNDERSTAND (15 min)

> **MS-4019 topics covered:** Module 1, *What are agents?* (prebuilt agents vs. agent templates vs. custom agents) and *Who can create and use agents?*

### Overview
Personal News Digest is an **agent template**, a declarative agent grounded in your **mailbox, Teams chats and SharePoint**. It sorts through company broadcast messages (leadership mail, announcement channels, intranet news) and gives you a short digest of what matters to your role and location. It leaves out peer and project chatter.

### Business scenario
It's 8:30 and Arjun opens his laptop. Overnight there's a CEO note on AI, a policy change on data handling, an HR deadline, an IT outage notice and 40 newsletters. Somewhere in there are the two things that will change his steering committee message.

### Pain points
- Company-wide updates get lost among broadcast mail, Teams posts and the intranet.
- Required actions (policies, trainings, deadlines) get missed.
- Checking every source takes 30–45 minutes every morning.
- What matters to a Program Manager in Bengaluru isn't what matters to everyone.

### Business benefits
- Replaces a 30–45 minute morning scan with a 3-minute read.
- Fewer missed policy, training and compliance deadlines.
- Faster alignment with leadership priorities.
- **Adoption:** a daily scheduled digest means a daily active user.

### Learning objectives
Learners will be able to:
1. Explain the difference between a **prebuilt agent**, an **agent template** and a **custom agent**.
2. Add the Personal News Digest template from the Agent Store or Agent Builder template gallery.
3. Write a role-aware **Goal → Context → Source → Expectations** prompt.
4. **Schedule** a daily briefing prompt.

### Environment setup
| Item | Requirement |
|---|---|
| Licence | Microsoft 365 Copilot (full licence; Copilot Chat alone isn't enough for agents grounded in work data) |
| Agents tab | Enabled by the tenant admin |
| Template | Personal News Digest visible in **Agents → Get agents / Agent Store** or in the **Agent Builder → template gallery** |
| Data | Your own mailbox and Teams; company announcements in the last 7–30 days |
| Trainer check | Ask *"Can you see Personal News Digest?"* If most learners can, do it hands-on. If none can, demo it only. Otherwise use trainer judgement. |
| Fallback | Use the **Fallback prompt** below in Copilot Chat (Work mode), or paste the sample announcements from `04_Sample-Data/Nexus_Sample_Announcements.md` into the chat. |

### Demo walkthrough
1. Open **Microsoft 365 Copilot Chat** → **Agents** → **Get agents / Agent Store** (or **New agent → templates**).
2. Search for **Personal News Digest** → **Add** (or **Create from template**, then **Create**).
3. Open the agent and point out the **conversation starters**. *Teaching point: this is a template, so Microsoft has already written the instructions and knowledge settings.*
4. Run **Prompt 1A (simple)**, then **Prompt 1B (structured)**.
5. Run the **follow-up**.
6. **Schedule it** (see below).

**Prompt 1A – simple (conversation-starter style)**
```
What are the top 5 company-wide announcements from the past week, tagged Critical, Important, or FYI? Include the sender and date for each.
```

**Prompt 1B – structured (Goal → Context → Source → Expectations)**
```
Goal: Give me a personalised morning briefing of what changed that matters to my work.
Context: I am a Program Manager leading Project Nexus, our internal rollout of Microsoft 365 Copilot and agents. I care about leadership direction on AI, policy changes that affect data or tools, training deadlines, and anything that affects employee adoption.
Source: Use company-wide announcements from my email, Teams announcement channels, and SharePoint news from the last 24 hours (or since my last working day).
Expectations: Show the 5 most relevant items only, as a table:
Priority (Critical / Important / FYI) | Headline | What happened | Why it matters to me | Action and deadline
End with one line: "The one thing I should mention in today's steering committee prep."
```

**Follow-up (makes it agentic)**
```
Which two of these items should change how I position Project Nexus to leadership this week? Explain why in two lines each.
```

**Extra prompts from the template's test set (use any)**
| Scenario | Prompt |
|---|---|
| Back from leave | `I just returned to the office. Catch me up on critical org news since the start of my time off.` |
| Policy action | `List recent policy changes that require employee action, including deadlines and links to the official policy.` |
| Leadership voice | `Surface messages and newsletters from the CEO, C-suite, or skip-levels in the past 30 days — include key quotes.` |
| Manager actions | `What announcements made by my manager in the past 14 days should my team pay attention to? Summarize key actions my team should take.` |
| Operational alerts | `Are there active incidents or planned outages I should know about?` |

### Schedule it 🔁
| Field | Value |
|---|---|
| Name | `Morning briefing – what changed` |
| Prompt | Prompt 1B |
| Frequency | Daily (weekdays where offered) |
| Time | 8:30 AM |
| Why | The habit is formed: Arjun's day starts with the digest already waiting. |

### Teaching moment
> *Search asks: "What happened?" Personal News Digest asks: "What happened **that matters to me**?"*

### Bridge to the next section
> "Arjun now knows what's changing **outside** his project. But his calendar, inbox and to-do list are still fighting for his attention. Next problem: **what actually matters today?**"

### If you drop this section
Open Section 2 with: *"Arjun starts his morning overwhelmed…"* Cover the **agent types** (Module 1) using Plan My Day instead.


---
*Part of the MS-4019 CUR_IND2 "A Day with Project Nexus" demo pack. See README.md for the full flow, environment setup and how to schedule prompts.*
