# Section 6 – 3:00 PM · SharePoint agent + sharing in Teams · SCALE (10 min, brief)

> **MS-4019 topics covered:** Module 3, *Create an agent in SharePoint*, *Manage your agents* (default site agent); Module 4, *Share an agent with other users*, *Share an agent in Microsoft Teams*, *Interact with agents*; **Lab:** *Exercise 2 – Create a SharePoint agent*.

### In one minute
Arjun creates a **"Nexus Help Desk"** SharePoint agent on the Project Nexus site, grounded in the team FAQ and rollout plan. He shares it in the **Nexus team chat** and adds it to the channel so people can **@mention** it. He also shares his **Nexus Delta Digest** agent with the workstream leads.

### Steps
1. Go to the Project Nexus SharePoint site → **Copilot / agent** → **Create an agent**.
2. **Overview:** name `Nexus Help Desk`. **Sources:** `Nexus_Team_FAQ.docx`, `Nexus_Rollout_Plan.docx`. **Behaviour:** welcome message and 3 starter prompts.
3. Test it:
   ```
   How do I get a Copilot licence, and who is the champion for Finance?
   ```
4. **Share:** copy the agent link → post it in the Nexus Teams chat → **@Nexus Help Desk** in the chat.
5. Share the **Nexus Delta Digest** (Copilot Chat agent) with **specific users** (the workstream leads).

### Key teaching points (Module 4)
- Shared agents respect permissions. **People only get answers from content they can already access.** Sharing the agent doesn't share the files.
- A site owner can set an approved agent as the **site's default agent**.
- Your chats with agents are private to you; you can rename or delete your chat history.

### Schedule it 🔁
Not applicable. SharePoint agents are used on demand by the team. The adoption benefit comes from **sharing**: every teammate who uses it becomes an active user.

### If you drop this section
Run the official SharePoint lab as self-paced. Keep one slide on **sharing and permissions** (Module 4) using the Delta Digest as the example.


---
*Part of the MS-4019 CUR_IND2 "A Day with Project Nexus" demo pack. See README.md for the full flow, environment setup and how to schedule prompts.*
