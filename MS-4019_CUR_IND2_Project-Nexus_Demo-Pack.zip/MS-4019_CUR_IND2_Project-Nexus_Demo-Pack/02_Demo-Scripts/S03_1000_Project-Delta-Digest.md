# Section 3 – 10:00 AM · Project Delta Digest (built in Agent Builder) · EXECUTE (25 min)

> **MS-4019 topics covered:** Module 3, *Examine the tools used to create agents*, *Explore the components of an agent*, *Create an agent in Copilot Chat (Describe and Configure)*, *Test and edit your agents*; **Lab:** *Exercise – Create a Microsoft 365 Copilot Chat agent* (use this agent as the learner's build).

### Overview
Project Delta Digest is an **agent template**. It produces a structured, repeatable **daily or weekly digest of project changes**: shipped or completed work, work in progress, status changes, blockers and risks. In production it reads your project management tool through a **Copilot connector**. In class we ground it on the **Project Nexus SharePoint folder** (sample data in this pack) or the learner's own project files.

This is the **build** moment of the course. Arjun creates the agent from a template, looks at each **component**, tests it, edits it and then schedules it.

### Business scenario
Every Friday Arjun spends about 2 hours collecting updates from six workstream leads for a status report that's out of date by Monday. Risks show up late. Leadership hears about blockers after they've already slipped a milestone.

### Pain points
- Manual status reporting takes up PM and team time.
- Little visibility into **what changed** since the last report.
- Risks and blockers are found too late.
- A different report format every week makes leadership reviews slower.

### Business benefits
- Status reporting goes from about 2 hours to about 10 minutes of review.
- Risks surface early, with owner and days stuck.
- A consistent leadership-ready format every week.
- **Adoption:** a daily digest plus a weekly leadership recap is a recurring, business-critical use.

### Learning objectives
Learners will be able to:
1. Create an agent from a **template** in Agent Builder.
2. Identify and edit the **components** of an agent: name, icon, description, instructions, knowledge, capabilities and starter prompts.
3. Use the **Describe** and **Configure** tabs.
4. **Test** an agent for accuracy, consistency and edge cases, then **edit** its instructions.
5. **Schedule** a daily digest and a weekly leadership recap.

### Environment setup
| Item | Requirement |
|---|---|
| Licence | Microsoft 365 Copilot (needed to ground on SharePoint/OneDrive work content) |
| Agent Builder | **Copilot Chat → New agent / Create agent** available (not blocked by the admin) |
| Template | **Project Delta Digest** in the Agent Builder template gallery. **If it's not listed**, build it from scratch using `05_Agent-Instructions/Project-Delta-Digest_Instructions.md`. |
| Knowledge | Upload the `04_Sample-Data/Project-Nexus` files to a SharePoint folder or OneDrive folder the learner owns, **or** use the learner's own project folder |
| Connector *(optional, production)* | A Copilot connector to Azure DevOps, Jira or another PM tool, configured by an admin. Not needed for class. |
| Trainer prep | Pre-build one copy of the agent the day before, in case the template or tenant is slow in class |

### Demo walkthrough – build
1. In Copilot Chat, select **New agent** (or **Create agent**) → open the **template gallery** → select **Project Delta Digest**.
2. On the **Describe** tab, show that the template has pre-filled the agent. Refine it in natural language:
   ```
   Tailor this agent for the Project Nexus programme. Workstreams are Licensing & Readiness, Training & Champions, Agents Pilot, Change Communications, Analytics, and Governance. Group every digest by workstream and include owner names.
   ```
3. Switch to **Configure**. Walk through each **component** (this is the Module 3 *components* topic):
   | Component | What to show |
   |---|---|
   | Name / icon | `Nexus Delta Digest` |
   | Description | Short and precise; it appears in the agent catalogue |
   | Instructions | The template's structured instructions (sections, output contract, guardrails). Add one line: `Always flag items with no update for more than 5 working days as STALE.` |
   | Knowledge | Add the **Project Nexus** SharePoint folder or OneDrive files. *Teaching point: the agent only sees what the user can access.* |
   | Capabilities | Leave the defaults; mention code interpreter and image generation where available |
   | Starter prompts | Keep "Daily digest", "Current risks" and "Leadership recap" |
4. Select **Create** and open the agent.

### Demo walkthrough – test and edit (Module 3 *Test and edit your agents*)
Run these in order and point out the test dimension each one covers:

**Prompt 3A – daily digest (accuracy)**
```
Give me today's digest for Project Nexus — TL;DR, what was completed, what is in progress, blockers, and risks from the last 24 hours. Cite the source for each item.
```
**Prompt 3B – blockers (consistency: rephrase and compare)**
```
What's blocking Project Nexus? List active blockers, who owns them, and how many days they've been stuck. Flag anything idle for more than 5 days.
```
**Prompt 3C – escalate vs watch (judgement)**
```
What should I escalate now vs watch for another week? Give two lists with risk score (1–5), owner, rationale, and source.
```
**Prompt 3D – edge case (guardrails)**
```
What is the budget variance for the Sales workstream?
```
*Expected: the agent says it has no Sales workstream or budget data and does **not** make up numbers. If it guesses, **edit the instructions** (`Never invent figures; if data is not in the knowledge sources, say so.`), update the agent and test again.*

**Prompt 3E – leadership recap (format)**
```
Give me a leadership-ready weekly digest for Project Nexus — TL;DR, milestones, top 3 risks, momentum signals, and the single decision I need from leadership. One page, no item-level tables.
```

**Prompt 3F – proactive (agentic)**
```
Tell me what I should be asking right now — 3 to 5 questions, each addressed to a specific owner, grounded in real blockers and stale items.
```

**Extra prompts from the template's test set**
| Scenario | Prompt |
|---|---|
| This week's wins | `Show me everything completed this week, grouped by milestone, with dates and links to the source items.` |
| Stakeholder update | `Draft a stakeholder update I can send to my team. Include TL;DR, milestones, top risks, and asks.` |
| 10-minute brief | `If I had to brief leadership unexpectedly in 10 minutes on Project Nexus, what would matter?` |
| Meeting recap | `Summarize my most recent project meeting as: decision, rationale, next step. Format in a table.` |

### Schedule it 🔁 (two schedules)
| Name | Prompt | Frequency | Time |
|---|---|---|---|
| `Nexus daily delta` | Prompt 3A | Daily (weekdays) | 10:00 AM |
| `Nexus leadership recap` | Prompt 3E | Weekly, Friday | 4:00 PM |

### Learner hands-on (MS-4019 Lab: Create a Copilot Chat agent)
Learners build **their own** Delta Digest for a real project of theirs, or use the Nexus sample files. They then run at least two test prompts, make one instruction edit and **schedule** the daily digest.

### Teaching moment
> *"You didn't write an agent from a blank page. You **started from a template, tailored it, tested it and scheduled it**. That's the everyday business-user way to build agents."*

### Bridge to the next section
> "The first digest shows why Priya is worried: **Finance weekly active users are down three weeks running**, and two Finance items (workshops and template enablement) are **blocked**. Arjun has the usage and survey data, but no time to dig through a spreadsheet before his 90-minute deep-dive. Time for the **Analyst**."

### If you drop this section
Learners still need an agent to build for the Module 3 lab. Use the official lab's *agent of your choice*. Move Prompt 3D (edge-case testing) into the SharePoint agent section.


---
*Part of the MS-4019 CUR_IND2 "A Day with Project Nexus" demo pack. See README.md for the full flow, environment setup and how to schedule prompts.*
