# Section 8 – 5:30 PM · Wrap my day: schedule, govern, commit (15 min)

> **MS-4019 topics covered:** Module 1, *Examine IT governance controls for your agents*; Module 4, *Interact with agents* (chat history, permissions); Module 5, *Learning path review*.

### Overview
This is the **most important section for adoption**. Learners leave having **scheduled at least 3 prompts**, so the agents come to them tomorrow.

### Step 1 – Show Arjun's schedule (2 min)
| Time | Agent | Scheduled prompt | Frequency | Outcome |
|---|---|---|---|---|
| 8:30 AM | Personal News Digest | Morning briefing – what changed | Daily | Understand |
| 9:00 AM | Plan My Day | Start my day | Daily | Prioritize |
| 10:00 AM | Nexus Delta Digest | Nexus daily delta | Daily | Execute |
| 4:00 PM Fri | Nexus Delta Digest | Nexus leadership recap | Weekly | Execute |
| 4:00 PM Mon | AI Learning Advisor | Weekly learning check-in | Weekly | Grow |
| 6:00 PM | Plan My Day | Wrap my day | Daily | Prioritize |

> **Talk track:** "Six scheduled prompts, about 5 minutes of reading a day. Arjun's agents now work for him **20+ days a month**, and he didn't have to remember any of it."

### Step 2 – Live: wrap Arjun's day (2 min)
In **Plan My Day**:
```
Wrap my day: summarise what I completed, what slipped, decisions I owe, and preview tomorrow's top 3 priorities.
```

### Step 3 – Learner hands-on: "Schedule 3" (8 min)
Every learner:
1. Picks **at least 3 prompts** from the **Scheduled Prompt Pack** (Section 10), including at least **2 daily** ones.
2. Personalises each one (role, project name, priorities).
3. Runs it once, checks the output, then **schedules it** (see *How to schedule a prompt*).
4. Opens the **scheduled prompts list** to confirm all 3 are there.
5. Posts **"✅ 3 scheduled"** in the class Teams chat.

### Step 4 – Governance check (3 min, Module 1 + 4)
Quick discussion:
- Scheduled prompts and agents **only use data the user can already access**. Permissions, sensitivity labels and DLP still apply.
- Check what you **share**: sharing an agent doesn't grant access to its knowledge sources.
- **Manage** scheduled prompts: pause or delete the ones you don't read. Unread digests are noise.
- Your agent chats are private. You can rename or delete your history.
- Your organisation decides which agents and templates are enabled (IT governance controls).

### Learning-path review (Module 5)
Ask: *"Which of Arjun's moments is most like your own day, and which agent did you schedule for it?"*


---
*Part of the MS-4019 CUR_IND2 "A Day with Project Nexus" demo pack. See README.md for the full flow, environment setup and how to schedule prompts.*
