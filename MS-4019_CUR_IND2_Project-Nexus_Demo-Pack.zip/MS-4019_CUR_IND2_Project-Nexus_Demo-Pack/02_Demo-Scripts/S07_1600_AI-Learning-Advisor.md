# Section 7 – 4:00 PM · AI Learning Advisor · GROW (15 min)

> **MS-4019 topics covered:** Module 6 (India preset), *personalised skilling*. It also reinforces Module 1, *Who can create and use agents?* (the path from business user to maker).

### Overview
AI Learning Advisor is an **agent template**, a declarative agent grounded in **Microsoft Learn** and the **Copilot Developer Camp** websites. It gives fast, trusted, step-by-step guidance and **personalised learning plans** across the Microsoft stack (Microsoft 365, Copilot Studio, Power Platform, Azure, Entra ID), with citations to official docs.

### Business scenario
Priya approved the plan, and added one more thing: *"You'll run the Finance agent workshops yourself."* Arjun is comfortable with Copilot, but he isn't confident explaining **agent grounding, knowledge, Agent Builder vs. Copilot Studio, or governance** to a room of finance professionals. The project has exposed a skill gap.

### Pain points
- Hundreds of learning resources and no clear path.
- Generic courses that don't match the learner's current level.
- No time; learning keeps getting pushed back.
- Repeated "how do I…?" questions going to subject-matter experts.

### Business benefits
- A focused, personalised learning path instead of browsing.
- Trusted answers with citations to Microsoft Learn.
- Subject-matter experts freed from repeated questions.
- **Adoption:** a weekly scheduled learning check-in keeps the learner coming back, and growing.

### Learning objectives
1. Add AI Learning Advisor from the template gallery or Agent Store.
2. Generate a **personalised 4-week learning plan** with a knowledge check.
3. Use it to answer "which tool when" questions (Agent Builder vs. Copilot Studio).
4. **Schedule** a weekly learning check-in.

### Environment setup
| Item | Requirement |
|---|---|
| Licence | Microsoft 365 Copilot; web/public website grounding allowed by the admin |
| Template | **AI Learning Advisor** (formerly "AI Skilling") in the template gallery or Agent Store |
| Fallback | If it isn't available: Copilot Chat with `Use Microsoft Learn as your primary source` added to the prompt, or build it quickly from `05_Agent-Instructions/AI-Learning-Advisor_Instructions.md` |

### Demo walkthrough
1. Add and open **AI Learning Advisor**.
2. Run **Prompt 7A**, then the **knowledge check (7B)**. Answer one or two questions live.
3. Run **Prompt 7C** (the which-tool-when question that every MS-4019 audience asks).
4. **Schedule it.**

**Prompt 7A – personalised plan**
```
Goal: Create a personalised learning journey so I can confidently explain and demonstrate Microsoft 365 Copilot agents to finance professionals.
Context: I am a Program Manager. I'm comfortable with Microsoft 365 Copilot and basic prompting. My gaps are agent grounding and knowledge sources, Agent Builder vs. Copilot Studio, agent sharing and governance, and designing finance use cases. I can spend 3 hours per week for 4 weeks.
Source: Prioritise Microsoft Learn and official Microsoft resources.
Expectations: A 4-week roadmap as a table:
Week | Skill | Why it matters for my workshops | Recommended learning (with link) | Hands-on activity | Evidence I've learned it
Prioritise impact. Don't overwhelm me.
```
**Prompt 7B – knowledge check (agentic: it adapts the plan)**
```
Before I start, test my existing knowledge with five questions, one at a time. Use my answers to adjust the 4-week plan.
```
**Prompt 7C – which tool when**
```
What's the difference between Agent Builder and Copilot Studio, and which should a finance business user use when? Give me a comparison table and a recommendation.
```

**Extra prompts from the template's test set**
| Scenario | Prompt |
|---|---|
| What's new | `What's new in Copilot Studio and Microsoft 365 Copilot and what should I try first?` |
| Explain simply | `Explain MCP (Model Context Protocol) like I am new to AI and why should I care as a maker?` |
| Brainstorm | `I am in Finance and new to building agents. Help me brainstorm 5 agent ideas with knowledge sources for each.` |
| Governance | `Give me a governance checklist for business users sharing agents in Microsoft 365 that I can show my IT team.` |

### Schedule it 🔁
| Name | Prompt | Frequency | Time |
|---|---|---|---|
| `Weekly learning check-in` | `It's a new week of my agent learning plan. Remind me of this week's skill, give me one 20-minute activity, and ask me one question to check last week's learning.` | Weekly, Monday | 4:00 PM |

> *Note: a scheduled prompt runs as a new conversation. Repeat the essential context (role, goal, plan) in the scheduled prompt, or ask the agent to rebuild the plan. Check in your tenant whether earlier chat context carries over.*

### Teaching moment
> *That's the difference between **content discovery** and **personalised learning**.*

### Bridge to the next section
> "It's 5:30. Arjun's day started with 200 unread items and no plan. Let's see what he's set up for tomorrow."

### If you drop this section
End the story at Section 5 or 6. Mention AI Learning Advisor in Section 8 as an optional agent to schedule.


---
*Part of the MS-4019 CUR_IND2 "A Day with Project Nexus" demo pack. See README.md for the full flow, environment setup and how to schedule prompts.*
