# Section 4 – 11:30 AM · Analyst · INVESTIGATE (20 min + official lab)

> **MS-4019 topics covered:** Module 2, *Examine the Analyst agent*; **Lab:** *Exercise 1 – Use the Analyst agent* (the official Project Nexus survey lab).

### Overview
Analyst explores, interprets and summarises work data (Excel, CSV, Word, Power BI) in natural language. It reasons step by step and can **run Python**, so you can see the code it ran and check its work.

### Business scenario
The Delta Digest flagged a drop in Finance adoption. Arjun has the Nexus adoption data (weekly active users by business unit, licences, survey sentiment). Priya wants to know **why** by this afternoon.

### Pain points
- Raw data, no analyst available, and the deadline is today.
- Pivot tables and charts take hours.
- Hard to tell a trend from noise.

### Business benefits
- Answers from data in minutes, not hours.
- Transparent reasoning (Python code you can see) builds trust.
- Ready-to-use charts for the steering committee.

### Learning objectives
1. Upload a data file to Analyst and ask analytical questions in natural language.
2. Read and check Analyst's reasoning and Python code.
3. Turn the findings into a chart and a 3-bullet insight for leadership.

### Environment setup
| Item | Requirement |
|---|---|
| Licence | Microsoft 365 Copilot |
| Agent | **Analyst** (prebuilt; under **Agents** in Copilot Chat) |
| Data | `04_Sample-Data/Project-Nexus/Nexus_Adoption_Data.xlsx` for the story demo; the **official lab spreadsheet** (Project Nexus survey results) for the hands-on |

### Demo walkthrough
1. Open **Analyst** → attach `Nexus_Adoption_Data.xlsx`.
2. Run Prompts 4A → 4C. Expand the **reasoning / code** panel at least once.

**Prompt 4A – trend**
```
Analyse weekly active users by business unit over the last 8 weeks. Which business unit is declining, since when, and by how much? Show a line chart.
```
**Prompt 4B – root cause**
```
For the declining business unit, compare licence assignment, training completion, and survey sentiment with the other business units. What are the three most likely reasons for the decline? Show the evidence for each.
```
**Prompt 4C – leadership-ready**
```
Summarise the findings as 3 bullets for a steering committee slide, plus one recommended action with an expected impact. Keep it under 80 words.
```

### Learner hands-on
Run the **official lab: Exercise 1 – Use the Analyst agent** (Project Nexus survey results). The story context makes it easy: *"You're Arjun's analyst. Find out what the survey says."*

### Schedule it 🔁 *(optional)*
Analyst is best used on demand. If the data file is updated weekly in OneDrive, an optional schedule is:
`Every Monday 9:30 AM – Compare this week's Nexus adoption data with last week. Flag any business unit that dropped more than 10%.`
*(Validate that scheduled runs can reach the file in your tenant.)*

### Bridge to the next section
> "Arjun now knows **what** is happening: Finance users weren't trained on agents and don't see their use cases. Priya wants a **recommendation**, backed by evidence, for what to do next."

### If you drop this section
Mention Analyst on one slide and keep the official lab as self-paced. In Section 5, give Researcher the finding directly: *"Finance adoption is down 30% because of a training gap."*


---
*Part of the MS-4019 CUR_IND2 "A Day with Project Nexus" demo pack. See README.md for the full flow, environment setup and how to schedule prompts.*
