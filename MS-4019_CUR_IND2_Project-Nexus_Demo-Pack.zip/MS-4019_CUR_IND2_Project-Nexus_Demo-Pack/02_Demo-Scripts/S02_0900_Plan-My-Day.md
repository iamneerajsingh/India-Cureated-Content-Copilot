# Section 2 – 9:00 AM · Plan My Day (+ Prompt Coach) · PRIORITIZE (15 min)

> **MS-4019 topics covered:** Module 1, *Explore the benefits of using agents* (task simplification, a personalised experience); Module 2, *Examine the Prompt Coach agent*.

### Overview
Plan My Day brings together your **meetings, tasks, emails and documents** in one time-aware briefing. It also re-plans your day when something changes. Prompt Coach is used here to improve Arjun's prompt **before** he schedules it, because a scheduled prompt is only as good as the prompt itself.

### Business scenario
Arjun has 9 meetings, a steering committee deck to draft, a stuck workstream and 30 minutes set aside to learn. He doesn't need another to-do list. He needs **prioritisation**. At 9:40 Priya asks for a 90-minute deep-dive on the Finance BU adoption drop, and the plan has to change.

### Pain points
- Calendar, inbox, Teams and Planner are all separate views; there's no single plan.
- Urgent work pushes out important work.
- Re-planning by hand after every interruption.
- Walking into meetings unprepared.

### Business benefits
- Less time spent planning each day (about 20 minutes saved).
- Protected focus time for top outcomes.
- Better meeting preparation.
- **Adoption:** two scheduled touchpoints each day (start and end) give strong daily usage.

### Learning objectives
Learners will be able to:
1. Use Plan My Day to build a time-blocked plan from their own work data.
2. **Re-plan** with a follow-up prompt when something changes (agentic behaviour).
3. Use **Prompt Coach** to improve a prompt.
4. **Schedule** a start-of-day and an end-of-day prompt.

### Environment setup
| Item | Requirement |
|---|---|
| Licence | Microsoft 365 Copilot |
| Agent | **Plan My Day**: first-party agent or template, depending on the tenant. Check **Agents → All agents / Agent Store**. |
| Prompt Coach | Prebuilt agent in Copilot Chat |
| Data | The learner's real calendar for today (at least 2–3 meetings works best), Outlook, Teams, Planner or To Do |
| Fallback | Run the same prompts in Copilot Chat (Work mode). The planning still works; you lose the agent's built-in structure. |

### Demo walkthrough
1. Open **Prompt Coach**. Paste Arjun's weak prompt:
   ```
   plan my day
   ```
   Then ask:
   ```
   Improve this prompt so an agent can build a realistic, time-blocked plan for a Program Manager. Use Goal, Context, Source, Expectations.
   ```
   *Teaching point: the coach adds context, sources and the output format. Compare the result with Prompt 2B.*
2. Open **Plan My Day** and run **Prompt 2A**, then **Prompt 2B**.
3. **Plot twist:** run **Prompt 2C** (the urgent request).
4. Show **Meeting prep** (Prompt 2D) for the next meeting on the calendar.
5. **Schedule it**, two prompts (see below).

**Prompt 2A – simple**
```
Prep my day
```

**Prompt 2B – structured**
```
Goal: Help me create a realistic, focused plan for today.
Context: I am a Program Manager leading Project Nexus. Today I must prepare for Monday's steering committee, unblock a delayed workstream, attend my scheduled meetings, handle urgent messages, and keep 30 minutes for learning. I want to avoid unnecessary context switching.
Source: Use my calendar, recent emails and Teams messages, tasks, and documents I am working on.
Expectations: Give me a time-blocked plan as a table:
Time | Activity | Priority (High/Med/Low) | Why this time makes sense
Then list my top 3 outcomes for today and anything I can safely postpone or delegate.
```

**Prompt 2C – plot twist (agentic re-plan)**
```
An urgent request just came in from my VP: a 90-minute deep-dive on why Finance adoption is dropping. Reorganise my day while protecting my top 3 outcomes. Tell me what moved and what I should decline or delegate.
```

**Prompt 2D – meeting prep**
```
Prep me for my next meeting: attendees, purpose, related documents, open action items, and the one question I should ask.
```

**Extra prompts from the template's test set**
| Scenario | Prompt |
|---|---|
| What did I miss | `What did I miss?` |
| Pending decisions | `Do I have any pending decisions or approvals where others are waiting on me?` |
| Meeting load | `How heavy is my meeting load today?` |
| Delegation | `What should I delegate today?` |
| Weekly look-ahead | `Give me a weekly look ahead` |

### Schedule it 🔁 (two schedules)
| Name | Prompt | Frequency | Time |
|---|---|---|---|
| `Start my day` | Prompt 2B | Daily (weekdays) | 9:00 AM |
| `Wrap my day` | `Wrap my day: summarise what I completed, what slipped, decisions I owe, and preview tomorrow's top 3 priorities.` | Daily (weekdays) | 6:00 PM |
| `Weekly look-ahead` *(optional)* | `Give me a weekly look ahead with milestones, meeting load, and top priorities.` | Weekly, Monday | 8:45 AM |

### Teaching moment
> *The first prompt shows **planning**. The plot twist shows something more valuable: **agentic experiences earn their place when circumstances change.***

### Bridge to the next section
> "Arjun's top outcome today is a clear Nexus status for the steering committee. But status lives in six people's heads, three trackers and a hundred messages. Instead of chasing people, he'll **build an agent** that does the chasing."

### If you drop this section
Cover Prompt Coach briefly in Section 3, using it to improve the Delta Digest prompt before scheduling. Move the "Wrap my day" schedule into Section 8.


---
*Part of the MS-4019 CUR_IND2 "A Day with Project Nexus" demo pack. See README.md for the full flow, environment setup and how to schedule prompts.*
