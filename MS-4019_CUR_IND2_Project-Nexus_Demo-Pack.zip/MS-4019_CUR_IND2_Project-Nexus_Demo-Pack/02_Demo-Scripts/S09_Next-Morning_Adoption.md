# Section 9 – Next morning · The adoption moment (trainer close + follow-up)

### Close the session (2 min)
> "Tomorrow at 8:30, your first digest will be waiting for you. You didn't just *try* an agent today. You made it part of your workday."

Shift the mindset from **"I tried an agent"** to **"I use this agent as part of my workflow."**

### Follow-up plan (for the trainer / CSM)
| When | Action | Owner |
|---|---|---|
| Day 1 | Share the copy-paste prompt pack in the class Teams chat | Trainer |
| Day 2 | Post: *"Did your 8:30 digest arrive? Reply with one useful item it found."* | Trainer / champion |
| Day 7 | Post: *"Pause one schedule you're not reading and add one that matters."* | Champion |
| Day 30 | Compare Agent MAU and PRU against the pre-training baseline (MSX / dashboard) | CSM / MTT lead |

### Success indicators
- % of learners with **at least 3 scheduled prompts** at the end of class (target: **80%**).
- % with **at least 2 daily** schedules (drives daily active usage).
- Agent MAU and PRU change at day 30.


---
*Part of the MS-4019 CUR_IND2 "A Day with Project Nexus" demo pack. See README.md for the full flow, environment setup and how to schedule prompts.*
